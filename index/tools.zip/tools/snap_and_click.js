const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');

// Simple arg parser: --key value or boolean flags
function parseArgs() {
  const args = { url: 'http://192.168.50.198/chat/editor/frontend/index.html', outDir: path.resolve(__dirname, '..', 'screenshots'), headless: true, listOnly: false, clear: false, actions: [], timeout: 60000, exePath: '' };
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.replace(/^--/, '');
      const next = argv[i + 1];
      if (typeof next === 'string' && !next.startsWith('--')) {
        args[key] = next;
        i++;
      } else {
        args[key] = true;
      }
    }
  }
  if (typeof args.headless === 'string') args.headless = args.headless !== 'false';
  if (typeof args.listOnly === 'string') args.listOnly = args.listOnly !== 'false';
  if (typeof args.clear === 'string') args.clear = args.clear !== 'false';
  if (typeof args.timeout === 'string') args.timeout = parseInt(args.timeout, 10) || 60000;
  if (typeof args.actions === 'string') args.actions = args.actions.split(',').map(s => s.trim()).filter(Boolean);
  return args;
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function clearScreenshotsIfNeeded(outDir, explicitClear = false) {
  // If marker exists, clear; otherwise create marker. Explicit --clear overrides.
  const marker = path.join(outDir, '.last_run');
  const shouldClear = explicitClear || fs.existsSync(marker);
  ensureDir(outDir);
  if (shouldClear) {
    for (const f of fs.readdirSync(outDir)) {
      if (f === '.last_run') continue;
      try {
        fs.unlinkSync(path.join(outDir, f));
      } catch {}
    }
  }
  try { fs.writeFileSync(marker, String(Date.now())); } catch {}
}

(async () => {
  const args = parseArgs();
  ensureDir(args.outDir);
  clearScreenshotsIfNeeded(args.outDir, !!args.clear);

  const report = { steps: [], foundButtons: [], meta: { url: args.url } };

  // Prefer the previously installed Chrome 141 path; allow override via --exePath
  let executablePath = undefined;
  const defaultChrome141 = 'C:/Users/cheng/.cache/puppeteer/chrome/win64-141.0.7390.78/chrome-win64/chrome.exe';
  if (args.exePath && fs.existsSync(args.exePath)) {
    executablePath = args.exePath;
  } else if (fs.existsSync(defaultChrome141)) {
    executablePath = defaultChrome141;
  }

  const browser = await puppeteer.launch({
    headless: args.headless ? 'new' : false,
    executablePath,
    defaultViewport: { width: 1366, height: 900 },
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();

  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  async function captureState(tag) {
    const state = await page.evaluate(() => {
      const iframe = document.querySelector('#preview-iframe');
      const consoleEl = document.querySelector('#console-output');
      const modal = document.querySelector('.modal.show');
      const editorEl = document.querySelector('#editor');
      return {
        url: location.href,
        iframe: iframe ? { src: iframe.getAttribute('src') || null, srcdocLen: (iframe.srcdoc || '').length } : null,
        consoleLen: consoleEl ? (consoleEl.textContent || '').length : null,
        modalVisible: !!modal,
        editorContentLen: editorEl ? (editorEl.textContent || '').length : null,
        ts: Date.now(),
      };
    });
    report.steps.push({ tag, state });
    console.log(tag, state);
  }

  async function shot(tag) {
    const file = path.join(args.outDir, `${tag}.png`);
    try {
      await page.screenshot({ path: file, fullPage: true });
      report.steps.push({ tag, screenshot: path.basename(file) });
      console.log('screenshot', file);
    } catch (e) {
      report.steps.push({ tag, screenshotError: String(e) });
      console.error('screenshotError', e);
    }
  }

  function normalizeActions(list) {
    // Map keywords to default selectors
    const map = {
      new: '#new-file-btn',
      open: '#open-file-btn',
      run: '#run-btn',
      stop: '#stop-btn'
    };
    return list.map(a => map[a] || a);
  }

  async function detectButtons() {
    const found = await page.evaluate(() => {
      const candidates = Array.from(document.querySelectorAll('button, [role="button"], a.button, .btn, [id$="-btn"], [data-action]'));
      return candidates.map(el => ({
        id: el.id || null,
        text: (el.textContent || '').trim(),
        role: el.getAttribute('role') || null,
        type: el.tagName.toLowerCase(),
        selector: el.id ? `#${el.id}` : (el.getAttribute('data-action') ? `[data-action="${el.getAttribute('data-action')}"]` : null)
      }));
    });
    report.foundButtons = found;
    console.log('foundButtons', found);
  }

  async function clickSelector(selector, tag, waitMs = 800) {
    let clicked = false;
    try {
      await page.waitForSelector(selector, { timeout: 2500 });
      const el = await page.$(selector);
      if (el) {
        await el.evaluate(e => e.scrollIntoView({ block: 'center' }));
        await el.click();
        clicked = true;
      }
    } catch (e) {
      console.warn('click warn', selector, e.message);
    }
    await sleep(waitMs);
    await captureState(`${tag}-state`);
    await shot(tag);
    report.steps.push({ tag, clicked, selector });
  }

  try {
    await page.goto(args.url, { waitUntil: 'domcontentloaded', timeout: args.timeout });
    await sleep(1000);
    await captureState('initial-state');
    await shot('step-0-initial');

    await detectButtons();

    if (args.listOnly) {
      // Only list buttons and take initial screenshot
      console.log(JSON.stringify({ buttons: report.foundButtons }, null, 2));
    } else {
      const actions = normalizeActions(args.actions.length ? args.actions : ['new','open','run','stop']);
      for (let i = 0; i < actions.length; i++) {
        const sel = actions[i];
        const tag = `step-${i+1}-${sel.replace(/[^a-zA-Z0-9_-]+/g,'')}`;
        await clickSelector(sel, tag, sel.includes('run') ? 1200 : 800);
      }
      // Ensure stop clicked at end if not included
      if (!actions.includes('#stop-btn')) {
        try {
          await clickSelector('#stop-btn', 'step-final-stop', 800);
        } catch {}
      }
    }

  } catch (err) {
    report.error = String(err);
    console.error('error', err);
  } finally {
    await browser.close();
    fs.writeFileSync(path.join(args.outDir, 'report.json'), JSON.stringify(report, null, 2));
    console.log('report saved at', path.join(args.outDir, 'report.json'));
  }
})();