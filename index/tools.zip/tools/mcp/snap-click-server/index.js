import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { execa } from "execa";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Utility: ensure dir exists
function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true });
}

// Build args for snap_and_click.js
function buildArgs(input) {
  const args = [];
  if (input?.url) args.push("--url", String(input.url));
  if (input?.outDir) args.push("--outDir", String(input.outDir));
  if (input?.listOnly) args.push("--listOnly");
  if (input?.clear) args.push("--clear");
  if (Array.isArray(input?.actions) && input.actions.length) {
    args.push("--actions", input.actions.join(","));
  }
  if (typeof input?.headless === "boolean") {
    args.push("--headless", String(input.headless));
  }
  if (input?.exePath) args.push("--exePath", String(input.exePath));
  return args;
}

// Execute the existing Node script and return report.json content with file list
async function runSnapAndClick(input) {
  const projectRoot = path.resolve(__dirname, "..", "..", "..");
  const scriptPath = path.resolve(projectRoot, "tools", "snap_and_click.js");
  const outDir = input?.outDir
    ? path.resolve(projectRoot, input.outDir)
    : path.resolve(projectRoot, "screenshots");

  ensureDir(outDir);
  const args = buildArgs(input);
  // Run the script
  await execa("node", [scriptPath, ...args], { cwd: projectRoot });

  // Collect outputs
  const reportPath = path.resolve(outDir, "report.json");
  let report = null;
  if (fs.existsSync(reportPath)) {
    try {
      report = JSON.parse(fs.readFileSync(reportPath, "utf-8"));
    } catch (e) {
      report = { error: String(e) };
    }
  }
  const files = fs.readdirSync(outDir).map((n) => path.join(outDir, n));
  return { outDir, report, files };
}

// Zod schemas for MCP tool IO
const SnapInputSchema = z.object({
  url: z.string().optional(),
  outDir: z.string().optional(),
  listOnly: z.boolean().optional(),
  clear: z.boolean().optional(),
  actions: z.array(z.string()).optional(),
  headless: z.boolean().optional(),
  exePath: z.string().optional(),
});

// Create MCP server
const server = new McpServer({
  name: "snap-click-mcp-server",
  version: "0.1.0",
});

// Tool: run full workflow
server.tool(
  "snap_and_click",
  "Run snap_and_click.js with parameters. Returns report.json and generated files.",
  SnapInputSchema,
  async (input) => {
    const res = await runSnapAndClick(input);
    return { content: [{ type: "json", json: res }] };
  }
);

// Tool: list buttons only
server.tool(
  "list_buttons",
  "Run snap_and_click.js with --listOnly to detect interactive buttons without clicking.",
  SnapInputSchema,
  async (input) => {
    const res = await runSnapAndClick({ ...input, listOnly: true });
    return { content: [{ type: "json", json: res }] };
  }
);

// Tool: clear screenshots dir by delegating to script with --clear + --listOnly
server.tool(
  "clear_screenshots",
  "Clear screenshots directory via snap_and_click.js --clear (uses last_run marker).",
  SnapInputSchema,
  async (input) => {
    const res = await runSnapAndClick({ ...input, clear: true, listOnly: true });
    return { content: [{ type: "json", json: res }] };
  }
);

// Start server over stdio transport
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
const transport = new StdioServerTransport();
await server.connect(transport);